﻿using System;

//members:
//1) Patel Disha
//2) Sundarajan Siddarth
//3) Faiaz Md

namespace _010_COMP123_02
{
    class EmployeeTest
    {
        static void Main(string[] args)
        {
            
            Employee emp = new Employee();                      //creating object 1 

            Employee emp1 = new Employee();                    //creating object 2 
          
            Console.WriteLine("Enter First Name");              //asking user to enter first name
            emp1.FirstName = Console.ReadLine();                //reading first name

           
            Console.WriteLine("Enter Last Name");                //asking user to enter last name
            emp1.LastName = Console.ReadLine();                  //reading last name

           
            Console.WriteLine("Enter Gross sales in positive");       //asking user to enter gross sales
            emp1.GrossSales = double.Parse(Console.ReadLine());       //reading gross Sales

           
            Console.WriteLine("Enter Base salary in positive");        //asking user to enter Base salary
            emp1.BasicSalary = double.Parse(Console.ReadLine());        //reading gross Sales

           
            Console.WriteLine("Enter commision rate in positive");      //asking user to enter CommisionRate
            emp1.CommissionRate = double.Parse(Console.ReadLine());     //reading commision rate
           
            //checking value of Gross sales and Commission Rate
            if (emp1.GrossSales > 0 && (emp1.CommissionRate > 0.1 && emp1.CommissionRate < 1.0))
            {
                //invoking object 1
                Console.WriteLine("Employee Id :"+ emp.EmployeeUserId + "\nName : " + emp.FirstName+ " " + emp.LastName
                                   + "\nBaseSalary: " + emp.BasicSalary + "\nGrossSales: " + emp.GrossSales +"\nComissionRate: " 
                                   +emp.CommissionRate);
     
                Console.WriteLine(emp.FirstName + "'s Commission : " + emp.Earnings() + " $ ");
                Console.WriteLine();

                //invoking object 2

                Console.WriteLine("Employee Id :" + (emp1.EmployeeUserId + 1) + "\nName : " + emp1.FirstName+ " " + emp1.LastName
                                   + "\nBaseSalary: " + emp1.BasicSalary + "\nGrossSales: " + emp1.GrossSales + "\nComissionRate: "
                                   + emp1.CommissionRate);
                Console.WriteLine(emp1.FirstName + "'s Commission : " + emp1.Earnings()+ " $");
            }
            else
            {
               
                Console.WriteLine("Enter gross sales > 0 and commission rate between 0.1 to 1.0");
            }
        }
    }
}
