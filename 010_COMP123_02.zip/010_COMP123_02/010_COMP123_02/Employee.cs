﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _010_COMP123_02
{
    class Employee
    {
        public readonly int EmployeeUserId;
        private string firstName;
        private string lastName;
        private double basicSalary = 2000;
        private double grossSales;
        private double commissionRate = 0.2;
        public string FirstName                    // property
        {
            get {
                return firstName; }              //getter
            set { 
                firstName = value; }             // setter
        }
        public string LastName                     // property
        {
            get {
                return lastName; }               //getter
            set {
                lastName = value; }              // setter
        }
        public double BasicSalary                  // property
        {
            get { 
                return basicSalary; }            //getter
            set { 
                basicSalary = value; }           // setter
        }
        public double GrossSales                   // property
        {
            get { 
                return grossSales; }             //getter
            set { 
                grossSales = value; }            // setter
        }
        public double CommissionRate               // property
        {
            get { 
                return commissionRate; }         //getter
            set { 
                commissionRate = value; }        // setter
        }


        //default constructor initilizing properties
        public Employee()
        { 

                EmployeeUserId = 1;
                firstName = "David";
                lastName = "Lio";
                commissionRate = 0.8;
                basicSalary = 2000;
                grossSales = 100;


        }

        //overloaded parameterized constructor

        public Employee(int employeeId, string fName, double bsalary)
        {
            
            this.EmployeeUserId = employeeId;
            firstName = fName;
            basicSalary = bsalary;
        }

        //method
        public double Earnings()
        {
            double comm = commissionRate * grossSales + basicSalary;
            return comm;
        }
    }
}

